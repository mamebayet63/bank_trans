export function closeTransactionPopup() {
  document.getElementById("transactionPopup").classList.add("hidden");
}

export function openTransactionPopup() {
  document.getElementById("transactionPopup").classList.remove("hidden");
}

export function openPersonPopup() {
  document.getElementById("personPopup").classList.remove("hidden");
}

export function closePersonPopup() {
  document.getElementById("personPopup").classList.add("hidden");
}
