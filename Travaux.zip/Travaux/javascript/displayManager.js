import { getCurrentUser } from "./userManager.js";

export function displayUserData() {
  const user = getCurrentUser();

  document.querySelector("#nom").textContent = `${user.prenom} ${user.nom}`;
  document.querySelector("#tel").textContent = `${user.telephone}`;
  document.querySelector("#montant").textContent = `${user.montant}€`;
  document.querySelector("#img").src = user.photo;

  const transactionsTable = document.getElementById("transactionsTable");
  transactionsTable.innerHTML = "";
  user.transactions.forEach((transaction) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td class="px-4 py-2 text-sm">${transaction.date}</td>
      <td class="px-4 py-2 text-sm">${transaction.numero}</td>
      <td class="px-4 py-2 text-sm">${transaction.type}</td>
      <td class="px-4 py-2 text-sm"><span class="${
        transaction.type == "retrait"
          ? "p-1 bg-purple-300 text-purple-500 rounded"
          : "p-1 bg-green-100 text-green-500 rounded"
      }">${transaction.montant}€</span></td>
    `;
    transactionsTable.appendChild(row);
  });
}
