import { getCurrentUser, saveUserDataToLocalStorage } from "./userManager.js";
import { displayUserData } from "./displayManager.js";
import { closeTransactionPopup } from "./modal.js";
import { showNotification } from "./notifications.js";

export function addTransaction(event) {
  event.preventDefault();
  const user = getCurrentUser();
  const validStart = [77, 76, 70];

  const date = document.getElementById("transactionDate").value;
  const numero = document.getElementById("transactionNumber").value;
  const type = document.getElementById("transactionType").value;
  const montant = parseFloat(
    document.getElementById("transactionAmount").value
  );
  let twoFirstNumber = parseInt(numero.slice(0, 2));
  let isValid = true;

  document.getElementById("numberError").textContent = "";
  document.getElementById("dateError").textContent = "";
  document.getElementById("selectError").textContent = "";
  document.getElementById("montantError").textContent = "";

  if (!date) {
    document.getElementById("dateError").textContent = "La date est requise.";
    document.getElementById("dateError").classList.add("text-red-500");
    isValid = false;
  }

  if (!numero) {
    document.getElementById("numberError").textContent =
      "Le numéro est requis.";
    document.getElementById("numberError").classList.add("text-red-500");
    isValid = false;
  }

  if (numero.length > 9) {
    document.getElementById("numberError").textContent =
      "Le numéro ne peut pas dépasser 9 chiffres.";
    document.getElementById("numberError").classList.add("text-red-500");
    isValid = false;
  }

  if (!validStart.includes(twoFirstNumber)) {
    document.getElementById("numberError").textContent =
      "Le téléphone doit commencer par (77,76,70).";
    document.getElementById("numberError").classList.add("text-red-500");
    isValid = false;
  }

  if (!type) {
    document.getElementById("selectError").textContent = "Le type est requis.";
    document.getElementById("selectError").classList.add("text-red-500");
    isValid = false;
  }

  if (isNaN(montant) || montant <= 0) {
    document.getElementById("montantError").textContent =
      "Le montant doit être supérieur à 0.";
    document.getElementById("montantError").classList.add("text-red-500");
    isValid = false;
  }

  if (type === "retrait" && montant > parseInt(user.montant)) {
    document.getElementById("montantError").textContent =
      "Vous n'avez pas assez d'argent pour le retrait";
    document.getElementById("montantError").classList.add("text-red-500");
    isValid = false;
  }

  if (type === "transfert" && montant > parseInt(user.montant)) {
    document.getElementById("montantError").textContent =
      "Vous n'avez pas assez d'argent pour le transfert";
    document.getElementById("montantError").classList.add("text-red-500");
    isValid = false;
  }

  if (!isValid) {
    return;
  }

  const newTransaction = {
    date: date,
    numero: numero,
    type: type,
    montant: type === "retrait" || type === "transfert" ? -montant : montant,
  };

  user.transactions.push(newTransaction);
  user.montant += newTransaction.montant;

  saveUserDataToLocalStorage();
  closeTransactionPopup();
  showNotification(
    `la transaction de ${newTransaction.type} a reussit`,
    "success"
  );
  displayUserData();
}
