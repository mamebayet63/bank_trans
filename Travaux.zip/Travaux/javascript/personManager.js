import {
  generateId,
  saveUserDataToLocalStorage,
  usersData,
} from "./userManager.js";
import { closePersonPopup } from "./modal.js";
import { displayUserData } from "./displayManager.js";
import { showNotification } from "./notifications.js";

export function addPerson(event) {
  event.preventDefault();
  const validStart = [77, 76, 70];
  const users = usersData;

  const name = document.getElementById("personName").value;
  const phone = document.getElementById("personPhone").value;
  const email = document.getElementById("personEmail").value;
  const prenom = document.getElementById("personFirstName").value;
  const photo = document.getElementById("personPhoto").value;

  let twoFirstNumber = parseInt(phone.slice(0, 2));

  let isValid = true;

  document.getElementById("nameError").textContent = "";
  document.getElementById("phoneError").textContent = "";
  document.getElementById("emailError").textContent = "";
  document.getElementById("prenomError").textContent = "";
  document.getElementById("photoError").textContent = "";

  if (!name) {
    document.getElementById("nameError").textContent = "Le nom est requis.";
    document.getElementById("nameError").classList.add("text-red-500");
    isValid = false;
  }

  if (!phone) {
    document.getElementById("phoneError").textContent =
      "Le téléphone est requis.";
    document.getElementById("phoneError").classList.add("text-red-500");
    isValid = false;
  }

  if (phone.length > 9) {
    document.getElementById("numberError").textContent =
      "Le numéro ne peut pas dépasser 9 chiffres.";
    document.getElementById("numberError").classList.add("text-red-500");
    isValid = false;
  }

  if (phone && !validStart.includes(twoFirstNumber)) {
    document.getElementById("phoneError").textContent =
      "Le téléphone doit commencer par (77,76,70).";
    document.getElementById("phoneError").classList.add("text-red-500");
    isValid = false;
  }

  if (!prenom) {
    document.getElementById("prenomError").textContent =
      "Le prénom est requis.";
    document.getElementById("prenomError").classList.add("text-red-500");
    isValid = false;
  }

  if (!email || !/\S+@\S+\.\S+/.test(email)) {
    document.getElementById("emailError").textContent =
      "Un email valide est requis.";
    document.getElementById("emailError").classList.add("text-red-500");
    isValid = false;
  }

  if (!photo) {
    document.getElementById("photoError").textContent =
      "Une URL de photo valide est requise.";
    document.getElementById("photoError").classList.add("text-red-500");
    isValid = false;
  }

  if (!isValid) {
    return;
  }

  const newPerson = {
    id: generateId(),
    nom: name,
    prenom: prenom,
    telephone: phone,
    email: email,
    montant: 0,
    photo: photo,
    transactions: [],
  };
  users.push(newPerson);
  saveUserDataToLocalStorage();
  closePersonPopup();
  showNotification(`Nouvelle personne ajouter avec success`, "success");
  displayUserData();
}
